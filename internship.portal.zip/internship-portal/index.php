<?php
session_start();

$isLoggedIn = isset($_SESSION["user_id"]);
$userName = $_SESSION["user_name"] ?? "";
$role = $_SESSION["role"] ?? "";
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="description"
        content="College Internship Application Portal"
    >

    <title>Internship Portal | Home</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

</head>

<body>

<div class="page-wrapper">

    <!-- Navigation -->

    <header class="navbar">

        <a href="index.php" class="logo">
            INTERNSHIP<span>PORTAL</span>
        </a>

        <nav>

            <a
                href="index.php"
                class="active"
            >
                Home
            </a>

            <?php if (!$isLoggedIn): ?>

                <a href="login.php">
                    Login
                </a>

                <a
                    href="register.php"
                    class="nav-button"
                >
                    Register
                </a>

            <?php else: ?>

                <?php if ($role === "student"): ?>

                    <a href="student/dashboard.php">
                        Dashboard
                    </a>

                <?php elseif ($role === "company"): ?>

                    <a href="company/dashboard.php">
                        Dashboard
                    </a>

                <?php endif; ?>

                <a href="logout.php">
                    Logout
                </a>

            <?php endif; ?>

        </nav>

    </header>


    <!-- Hero Section -->

    <main>

        <section class="hero-section">

            <div class="hero-content">

                <p class="eyebrow">
                    COLLEGE INTERNSHIP APPLICATION PORTAL
                </p>

                <h1>
                    Connect Talent
                    <span>With Opportunity.</span>
                </h1>

                <p class="hero-description">
                    A centralized platform where students discover
                    internships and companies find emerging talent.
                    Search, apply, track and manage internships from
                    one secure portal.
                </p>


                <div class="hero-actions">

                    <?php if (!$isLoggedIn): ?>

                        <a
                            href="register.php"
                            class="btn btn-primary"
                        >
                            Get Started
                        </a>

                        <a
                            href="login.php"
                            class="btn btn-secondary"
                        >
                            Login
                        </a>

                    <?php elseif ($role === "student"): ?>

                        <a
                            href="student/internships.php"
                            class="btn btn-primary"
                        >
                            Find Internships
                        </a>

                        <a
                            href="student/dashboard.php"
                            class="btn btn-secondary"
                        >
                            My Dashboard
                        </a>

                    <?php elseif ($role === "company"): ?>

                        <a
                            href="company/add_internship.php"
                            class="btn btn-primary"
                        >
                            Post Internship
                        </a>

                        <a
                            href="company/dashboard.php"
                            class="btn btn-secondary"
                        >
                            My Dashboard
                        </a>

                    <?php endif; ?>

                </div>

            </div>


            <!-- Hero Visual -->

            <div class="hero-visual">

                <div class="orbit orbit-one"></div>

                <div class="orbit orbit-two"></div>

                <div class="hero-panel">

                    <div class="panel-header">

                        <span class="status-dot"></span>

                        <span>
                            INTERNSHIP NETWORK
                        </span>

                    </div>

                    <div class="network-line"></div>

                    <div class="network-items">

                        <div class="network-card">

                            <strong>
                                STUDENTS
                            </strong>

                            <span>
                                Discover
                            </span>

                        </div>

                        <div class="network-card">

                            <strong>
                                COMPANIES
                            </strong>

                            <span>
                                Recruit
                            </span>

                        </div>

                        <div class="network-card">

                            <strong>
                                CAREERS
                            </strong>

                            <span>
                                Connect
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </section>


        <!-- Features -->

        <section class="features-section">

            <div class="section-heading">

                <p class="eyebrow">
                    PLATFORM FEATURES
                </p>

                <h2>
                    Everything You Need
                </h2>

                <p>
                    Simple tools for students and companies
                    throughout the internship lifecycle.
                </p>

            </div>


            <div class="feature-grid">

                <article class="feature-card">

                    <div class="feature-number">
                        01
                    </div>

                    <h3>
                        Discover
                    </h3>

                    <p>
                        Search internships using titles,
                        skills and locations that match
                        your career interests.
                    </p>

                </article>


                <article class="feature-card">

                    <div class="feature-number">
                        02
                    </div>

                    <h3>
                        Apply
                    </h3>

                    <p>
                        Submit internship applications
                        with your profile and resume
                        through a streamlined process.
                    </p>

                </article>


                <article class="feature-card">

                    <div class="feature-number">
                        03
                    </div>

                    <h3>
                        Track
                    </h3>

                    <p>
                        Monitor your application status
                        from Applied through the final
                        selection decision.
                    </p>

                </article>


                <article class="feature-card">

                    <div class="feature-number">
                        04
                    </div>

                    <h3>
                        Recruit
                    </h3>

                    <p>
                        Companies can publish internships,
                        review applicants and manage
                        candidate status.
                    </p>

                </article>

            </div>

        </section>


        <!-- Workflow -->

        <section class="workflow-section">

            <div class="section-heading">

                <p class="eyebrow">
                    APPLICATION WORKFLOW
                </p>

                <h2>
                    From Application to Opportunity
                </h2>

            </div>


            <div class="workflow">

                <div class="workflow-step">

                    <span>01</span>

                    <h3>
                        Applied
                    </h3>

                    <p>
                        Student submits an application.
                    </p>

                </div>


                <div class="workflow-arrow">
                    →
                </div>


                <div class="workflow-step">

                    <span>02</span>

                    <h3>
                        Under Review
                    </h3>

                    <p>
                        Company evaluates the application.
                    </p>

                </div>


                <div class="workflow-arrow">
                    →
                </div>


                <div class="workflow-step">

                    <span>03</span>

                    <h3>
                        Shortlisted
                    </h3>

                    <p>
                        Candidate moves to the next stage.
                    </p>

                </div>


                <div class="workflow-arrow">
                    →
                </div>


                <div class="workflow-step">

                    <span>04</span>

                    <h3>
                        Interview
                    </h3>

                    <p>
                        Candidate proceeds to interview.
                    </p>

                </div>


                <div class="workflow-arrow">
                    →
                </div>


                <div class="workflow-step">

                    <span>05</span>

                    <h3>
                        Selected
                    </h3>

                    <p>
                        Internship opportunity is confirmed.
                    </p>

                </div>

            </div>

        </section>


        <!-- CTA -->

        <section class="cta-section">

            <div>

                <p class="eyebrow">
                    START YOUR JOURNEY
                </p>

                <h2>
                    Build Your Next Career Opportunity.
                </h2>

                <p>
                    Join the platform and take the next step
                    toward meaningful internship opportunities.
                </p>

            </div>


            <div>

                <?php if (!$isLoggedIn): ?>

                    <a
                        href="register.php"
                        class="btn btn-primary"
                    >
                        Create Account
                    </a>

                <?php elseif ($role === "student"): ?>

                    <a
                        href="student/internships.php"
                        class="btn btn-primary"
                    >
                        Explore Internships
                    </a>

                <?php elseif ($role === "company"): ?>

                    <a
                        href="company/add_internship.php"
                        class="btn btn-primary"
                    >
                        Post Internship
                    </a>

                <?php endif; ?>

            </div>

        </section>

    </main>


    <!-- Footer -->

    <footer class="footer">

        <div>

            <strong>
                INTERNSHIP PORTAL
            </strong>

            <p>
                College Internship Application Portal
            </p>

        </div>

        <div>

            <p>
                Secure • Simple • Career Focused
            </p>

        </div>

    </footer>

</div>


<script src="js/validation.js"></script>

</body>

</html>