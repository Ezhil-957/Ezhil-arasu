<?php

session_start();

require_once __DIR__ . "/config/database.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($email === "" || $password === "") {

        $error = "Please enter your email and password.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Please enter a valid email address.";

    } else {

        try {

            $stmt = $conn->prepare(
                "SELECT id, name, email, password, role
                 FROM users
                 WHERE email = ?
                 LIMIT 1"
            );

            $stmt->execute([$email]);

            $user = $stmt->fetch();

            if ($user && password_verify($password, $user["password"])) {

                /*
                 * Regenerate session ID after successful login
                 * to prevent session fixation.
                 */
                session_regenerate_id(true);

                $_SESSION["user_id"] = $user["id"];
                $_SESSION["user_name"] = $user["name"];
                $_SESSION["user_email"] = $user["email"];
                $_SESSION["role"] = $user["role"];

                if ($user["role"] === "student") {

                    header("Location: student/dashboard.php");
                    exit;

                } elseif ($user["role"] === "company") {

                    header("Location: company/dashboard.php");
                    exit;

                } else {

                    $error = "Invalid account role.";
                }

            } else {

                $error = "Invalid email or password.";
            }

        } catch (PDOException $e) {

            $error = "Unable to process login. Please try again.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Login | Internship Portal</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

</head>

<body>

<div class="page-wrapper">

    <!-- Navigation -->

    <header class="navbar">

        <div class="logo">
            INTERNSHIP<span>PORTAL</span>
        </div>

        <nav>

            <a href="index.php">
                Home
            </a>

            <a href="register.php">
                Register
            </a>

        </nav>

    </header>


    <!-- Login -->

    <main class="auth-container">

        <section class="auth-card">

            <div class="auth-header">

                <p class="eyebrow">
                    SECURE ACCESS
                </p>

                <h1>
                    Welcome Back
                </h1>

                <p>
                    Login to continue to your internship portal.
                </p>

            </div>


            <?php if ($error !== ""): ?>

                <div class="alert alert-error">
                    <?= htmlspecialchars($error) ?>
                </div>

            <?php endif; ?>


            <form
                method="POST"
                action="login.php"
                id="loginForm"
                novalidate
            >

                <div class="form-group">

                    <label for="email">
                        Email Address
                    </label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Enter your email"
                        value="<?= htmlspecialchars($_POST["email"] ?? "") ?>"
                        autocomplete="email"
                        required
                    >

                </div>


                <div class="form-group">

                    <label for="password">
                        Password
                    </label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Enter your password"
                        autocomplete="current-password"
                        required
                    >

                </div>


                <button
                    type="submit"
                    class="btn btn-primary btn-full"
                >
                    Login
                </button>

            </form>


            <div class="auth-footer">

                Don't have an account?

                <a href="register.php">
                    Create Account
                </a>

            </div>

        </section>

    </main>


    <footer class="footer">

        <p>
            College Internship Application Portal
        </p>

    </footer>

</div>


<script src="js/validation.js"></script>

</body>

</html>