<?php
session_start();

require_once __DIR__ . '/config/database.php';

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirm_password = $_POST["confirm_password"] ?? "";
    $role = $_POST["role"] ?? "";

    if ($name === "" || $email === "" || $password === "" || $confirm_password === "" || $role === "") {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (!in_array($role, ["student", "company"], true)) {
        $error = "Invalid account type.";
    } elseif (strlen($password) < 6) {
        $error = "Password must contain at least 6 characters.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {

        try {

            // Check whether email already exists
            $check = $conn->prepare(
                "SELECT id FROM users WHERE email = ? LIMIT 1"
            );

            $check->execute([$email]);

            if ($check->fetch()) {

                $error = "An account with this email already exists.";

            } else {

                $hashedPassword = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $conn->beginTransaction();

                // Create user
                $stmt = $conn->prepare(
                    "INSERT INTO users
                    (name, email, password, role)
                    VALUES (?, ?, ?, ?)"
                );

                $stmt->execute([
                    $name,
                    $email,
                    $hashedPassword,
                    $role
                ]);

                $userId = $conn->lastInsertId();

                // Create role-specific record
                if ($role === "student") {

                    $studentStmt = $conn->prepare(
                        "INSERT INTO students (user_id)
                         VALUES (?)"
                    );

                    $studentStmt->execute([$userId]);

                } elseif ($role === "company") {

                    $companyStmt = $conn->prepare(
                        "INSERT INTO companies
                        (user_id, company_name)
                        VALUES (?, ?)"
                    );

                    $companyStmt->execute([
                        $userId,
                        $name
                    ]);
                }

                $conn->commit();

                $success = "Registration successful. You can now login.";

            }

        } catch (PDOException $e) {

            if ($conn->inTransaction()) {
                $conn->rollBack();
            }

            $error = "Registration failed. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Create Account | Internship Portal</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

</head>

<body>

<div class="page-wrapper">

    <header class="navbar">

        <div class="logo">
            INTERNSHIP<span>PORTAL</span>
        </div>

        <nav>

            <a href="index.php">
                Home
            </a>

            <a href="login.php">
                Login
            </a>

        </nav>

    </header>


    <main class="auth-container">

        <section class="auth-card">

            <div class="auth-header">

                <p class="eyebrow">
                    CREATE ACCOUNT
                </p>

                <h1>
                    Join the Internship Portal
                </h1>

                <p>
                    Create your student or company account.
                </p>

            </div>


            <?php if ($error !== ""): ?>

                <div class="alert alert-error">
                    <?= htmlspecialchars($error) ?>
                </div>

            <?php endif; ?>


            <?php if ($success !== ""): ?>

                <div class="alert alert-success">

                    <?= htmlspecialchars($success) ?>

                    <div style="margin-top: 12px;">

                        <a
                            href="login.php"
                            class="btn btn-primary"
                        >
                            Go to Login
                        </a>

                    </div>

                </div>

            <?php endif; ?>


            <form
                method="POST"
                action="register.php"
                id="registerForm"
                novalidate
            >

                <div class="form-group">

                    <label for="name">
                        Full Name
                    </label>

                    <input
                        type="text"
                        id="name"
                        name="name"
                        placeholder="Enter your full name"
                        value="<?= htmlspecialchars($_POST["name"] ?? "") ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label for="email">
                        Email Address
                    </label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Enter your email"
                        value="<?= htmlspecialchars($_POST["email"] ?? "") ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label for="role">
                        Account Type
                    </label>

                    <select
                        id="role"
                        name="role"
                        required
                    >

                        <option value="">
                            Select account type
                        </option>

                        <option
                            value="student"
                            <?= (($_POST["role"] ?? "") === "student") ? "selected" : "" ?>
                        >
                            Student
                        </option>

                        <option
                            value="company"
                            <?= (($_POST["role"] ?? "") === "company") ? "selected" : "" ?>
                        >
                            Company
                        </option>

                    </select>

                </div>


                <div class="form-row">

                    <div class="form-group">

                        <label for="password">
                            Password
                        </label>

                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Minimum 6 characters"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label for="confirm_password">
                            Confirm Password
                        </label>

                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            placeholder="Re-enter password"
                            required
                        >

                    </div>

                </div>


                <button
                    type="submit"
                    class="btn btn-primary btn-full"
                >
                    Create Account
                </button>

            </form>


            <div class="auth-footer">

                Already have an account?

                <a href="login.php">
                    Login here
                </a>

            </div>

        </section>

    </main>


    <footer class="footer">

        <p>
            College Internship Application Portal
        </p>

    </footer>

</div>


<script src="js/validation.js"></script>

</body>

</html>