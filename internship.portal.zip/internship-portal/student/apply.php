<?php

session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION["user_id"];
$internshipId = (int) ($_GET["id"] ?? $_POST["internship_id"] ?? 0);

if ($internshipId <= 0) {
    header("Location: internships.php");
    exit;
}

$error = "";
$success = "";

try {

    $stmt = $conn->prepare("
        SELECT
            i.*,
            c.company_name
        FROM internships i
        INNER JOIN companies c
            ON c.id = i.company_id
        WHERE i.id = ?
        LIMIT 1
    ");

    $stmt->execute([$internshipId]);

    $internship = $stmt->fetch();

    if (!$internship) {
        header("Location: internships.php");
        exit;
    }


    $studentStmt = $conn->prepare("
        SELECT id, resume
        FROM students
        WHERE user_id = ?
        LIMIT 1
    ");

    $studentStmt->execute([$userId]);

    $student = $studentStmt->fetch();

    if (!$student) {
        $error = "Student profile not found.";
    }


    if ($_SERVER["REQUEST_METHOD"] === "POST" && $error === "") {

        $studentId = (int) $student["id"];

        $check = $conn->prepare("
            SELECT id
            FROM applications
            WHERE internship_id = ?
              AND student_id = ?
            LIMIT 1
        ");

        $check->execute([
            $internshipId,
            $studentId
        ]);

        if ($check->fetch()) {

            $error = "You have already applied for this internship.";

        } elseif (empty($student["resume"])) {

            $error = "Please upload your resume in your profile before applying.";

        } else {

            $applyStmt = $conn->prepare("
                INSERT INTO applications
                (
                    internship_id,
                    student_id,
                    resume,
                    status
                )
                VALUES (?, ?, ?, 'Applied')
            ");

            $applyStmt->execute([
                $internshipId,
                $studentId,
                $student["resume"]
            ]);

            $success = "Application submitted successfully.";
        }
    }

} catch (PDOException $e) {

    $error = "Unable to process the application.";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Apply | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="page-wrapper">

<header class="navbar">

    <a href="../index.php" class="logo">
        INTERNSHIP<span>PORTAL</span>
    </a>

    <nav>

        <a href="../index.php">Home</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="profile.php">Profile</a>
        <a href="internships.php" class="active">Internships</a>
        <a href="applications.php">Applications</a>
        <a href="../logout.php">Logout</a>

    </nav>

</header>


<main class="form-page">

    <section class="form-card">

        <p class="eyebrow">INTERNSHIP APPLICATION</p>

        <h1>
            <?= htmlspecialchars($internship["title"]) ?>
        </h1>

        <h3>
            <?= htmlspecialchars($internship["company_name"]) ?>
        </h3>


        <?php if ($error): ?>

            <div class="alert alert-error">
                <?= htmlspecialchars($error) ?>
            </div>

        <?php endif; ?>


        <?php if ($success): ?>

            <div class="alert alert-success">

                <?= htmlspecialchars($success) ?>

                <br><br>

                <a href="applications.php" class="btn btn-primary">
                    Track Application
                </a>

            </div>

        <?php endif; ?>


        <div class="application-details">

            <p>
                <strong>Description</strong><br>
                <?= nl2br(
                    htmlspecialchars(
                        $internship["description"]
                    )
                ) ?>
            </p>

            <p>
                <strong>Required Skills</strong><br>
                <?= htmlspecialchars($internship["skills_required"]) ?>
            </p>

            <p>
                <strong>Location</strong><br>
                <?= htmlspecialchars($internship["location"]) ?>
            </p>

            <p>
                <strong>Stipend</strong><br>
                <?= htmlspecialchars($internship["stipend"]) ?>
            </p>

            <p>
                <strong>Duration</strong><br>
                <?= htmlspecialchars($internship["duration"]) ?>
            </p>

            <p>
                <strong>Deadline</strong><br>
                <?= htmlspecialchars($internship["deadline"]) ?>
            </p>

        </div>


        <?php if (!$success): ?>

            <form method="POST">

                <input
                    type="hidden"
                    name="internship_id"
                    value="<?= $internshipId ?>"
                >

                <?php if (empty($student["resume"])): ?>

                    <div class="alert alert-warning">
                        Please upload your resume in your profile before applying.
                    </div>

                    <a
                        href="profile.php"
                        class="btn btn-secondary"
                    >
                        Upload Resume
                    </a>

                <?php else: ?>

                    <p class="file-info">
                        Your uploaded resume will be submitted with this application.
                    </p>

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >
                        Submit Application
                    </button>

                <?php endif; ?>

            </form>

        <?php endif; ?>

    </section>

</main>


<footer class="footer">
    <p>College Internship Application Portal</p>
</footer>

</div>

</body>

</html>