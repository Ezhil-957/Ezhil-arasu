<?php

session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit;
}

$search = trim($_GET["search"] ?? "");
$location = trim($_GET["location"] ?? "");

try {

    $sql = "
        SELECT
            i.id,
            i.title,
            i.description,
            i.skills_required,
            i.location,
            i.stipend,
            i.duration,
            i.deadline,
            c.company_name
        FROM internships i
        INNER JOIN companies c
            ON c.id = i.company_id
        WHERE 1 = 1
    ";

    $params = [];

    if ($search !== "") {

        $sql .= "
            AND (
                i.title LIKE ?
                OR i.description LIKE ?
                OR i.skills_required LIKE ?
                OR c.company_name LIKE ?
            )
        ";

        $term = "%" . $search . "%";

        $params[] = $term;
        $params[] = $term;
        $params[] = $term;
        $params[] = $term;
    }

    if ($location !== "") {

        $sql .= " AND i.location LIKE ? ";

        $params[] = "%" . $location . "%";
    }

    $sql .= " ORDER BY i.created_at DESC";

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    $internships = $stmt->fetchAll();

} catch (PDOException $e) {

    $internships = [];
    $error = "Unable to load internships.";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Internships | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="page-wrapper">

<header class="navbar">

    <a href="../index.php" class="logo">
        INTERNSHIP<span>PORTAL</span>
    </a>

    <nav>

        <a href="../index.php">Home</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="profile.php">Profile</a>
        <a href="internships.php" class="active">Internships</a>
        <a href="applications.php">Applications</a>
        <a href="../logout.php">Logout</a>

    </nav>

</header>


<main class="content-container">

    <section class="page-header">

        <p class="eyebrow">OPPORTUNITY DISCOVERY</p>

        <h1>Find Internships</h1>

        <p>
            Search internships by role, skills, company or location.
        </p>

    </section>


    <section class="search-panel">

        <form method="GET" class="search-form">

            <div class="form-group">

                <label>Search</label>

                <input
                    type="text"
                    name="search"
                    value="<?= htmlspecialchars($search) ?>"
                    placeholder="PHP, Web Developer, AI..."
                >

            </div>


            <div class="form-group">

                <label>Location</label>

                <input
                    type="text"
                    name="location"
                    value="<?= htmlspecialchars($location) ?>"
                    placeholder="Chennai, Bangalore..."
                >

            </div>


            <button type="submit" class="btn btn-primary">
                Search
            </button>

            <a href="internships.php" class="btn btn-secondary">
                Clear
            </a>

        </form>

    </section>


    <?php if (isset($error)): ?>

        <div class="alert alert-error">
            <?= htmlspecialchars($error) ?>
        </div>

    <?php endif; ?>


    <section class="internship-grid">

        <?php if (count($internships) === 0): ?>

            <div class="empty-state">

                <h2>No internships found</h2>

                <p>
                    Try another search or check back later.
                </p>

            </div>

        <?php endif; ?>


        <?php foreach ($internships as $internship): ?>

            <article class="internship-card">

                <div class="card-top">

                    <span class="badge">
                        INTERNSHIP
                    </span>

                    <span class="location">
                        <?= htmlspecialchars($internship["location"]) ?>
                    </span>

                </div>


                <h2>
                    <?= htmlspecialchars($internship["title"]) ?>
                </h2>


                <h3>
                    <?= htmlspecialchars($internship["company_name"]) ?>
                </h3>


                <p>
                    <?= nl2br(
                        htmlspecialchars(
                            $internship["description"]
                        )
                    ) ?>
                </p>


                <div class="detail-list">

                    <span>
                        <strong>Skills:</strong>
                        <?= htmlspecialchars($internship["skills_required"]) ?>
                    </span>

                    <span>
                        <strong>Stipend:</strong>
                        <?= htmlspecialchars($internship["stipend"]) ?>
                    </span>

                    <span>
                        <strong>Duration:</strong>
                        <?= htmlspecialchars($internship["duration"]) ?>
                    </span>

                    <span>
                        <strong>Deadline:</strong>
                        <?= htmlspecialchars($internship["deadline"]) ?>
                    </span>

                </div>


                <a
                    href="apply.php?id=<?= (int) $internship["id"] ?>"
                    class="btn btn-primary btn-full"
                >
                    View & Apply
                </a>

            </article>

        <?php endforeach; ?>

    </section>

</main>


<footer class="footer">
    <p>College Internship Application Portal</p>
</footer>

</div>

<script src="../js/validation.js"></script>

</body>

</html>