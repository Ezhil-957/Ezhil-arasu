<?php

session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION["user_id"];

try {

    $stmt = $conn->prepare("
        SELECT
            u.name,
            u.email,
            s.id AS student_id,
            s.college,
            s.course,
            s.skills,
            s.resume
        FROM users u
        LEFT JOIN students s ON s.user_id = u.id
        WHERE u.id = ?
        LIMIT 1
    ");

    $stmt->execute([$userId]);

    $student = $stmt->fetch();

    if (!$student) {
        session_destroy();
        header("Location: ../login.php");
        exit;
    }

    $studentId = (int) $student["student_id"];

    $countStmt = $conn->prepare("
        SELECT
            COUNT(*) AS total,
            SUM(status = 'Applied') AS applied,
            SUM(status = 'Under Review') AS under_review,
            SUM(status = 'Shortlisted') AS shortlisted,
            SUM(status = 'Interview') AS interview,
            SUM(status = 'Selected') AS selected,
            SUM(status = 'Rejected') AS rejected
        FROM applications
        WHERE student_id = ?
    ");

    $countStmt->execute([$studentId]);

    $stats = $countStmt->fetch();

} catch (PDOException $e) {

    $student = [
        "name" => $_SESSION["user_name"],
        "email" => $_SESSION["user_email"],
        "college" => "",
        "course" => "",
        "skills" => "",
        "resume" => ""
    ];

    $stats = [
        "total" => 0,
        "applied" => 0,
        "under_review" => 0,
        "shortlisted" => 0,
        "interview" => 0,
        "selected" => 0,
        "rejected" => 0
    ];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Dashboard | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="page-wrapper">

    <header class="navbar">

        <a href="../index.php" class="logo">
            INTERNSHIP<span>PORTAL</span>
        </a>

        <nav>

            <a href="../index.php">Home</a>

            <a href="dashboard.php" class="active">Dashboard</a>

            <a href="profile.php">Profile</a>

            <a href="internships.php">Internships</a>

            <a href="applications.php">Applications</a>

            <a href="../logout.php">Logout</a>

        </nav>

    </header>


    <main class="dashboard-container">

        <section class="dashboard-header">

            <div>

                <p class="eyebrow">STUDENT DASHBOARD</p>

                <h1>
                    Welcome, <?= htmlspecialchars($student["name"]) ?>
                </h1>

                <p>
                    Discover opportunities and manage your internship journey.
                </p>

            </div>

            <a href="internships.php" class="btn btn-primary">
                Find Internships
            </a>

        </section>


        <section class="stats-grid">

            <div class="stat-card">
                <span>Total Applications</span>
                <strong><?= (int) ($stats["total"] ?? 0) ?></strong>
            </div>

            <div class="stat-card">
                <span>Applied</span>
                <strong><?= (int) ($stats["applied"] ?? 0) ?></strong>
            </div>

            <div class="stat-card">
                <span>Under Review</span>
                <strong><?= (int) ($stats["under_review"] ?? 0) ?></strong>
            </div>

            <div class="stat-card">
                <span>Shortlisted</span>
                <strong><?= (int) ($stats["shortlisted"] ?? 0) ?></strong>
            </div>

            <div class="stat-card">
                <span>Interview</span>
                <strong><?= (int) ($stats["interview"] ?? 0) ?></strong>
            </div>

            <div class="stat-card">
                <span>Selected</span>
                <strong><?= (int) ($stats["selected"] ?? 0) ?></strong>
            </div>

        </section>


        <section class="dashboard-grid">

            <div class="dashboard-card">

                <div class="card-heading">

                    <div>
                        <p class="eyebrow">PROFILE</p>
                        <h2>Your Profile</h2>
                    </div>

                    <a href="profile.php" class="text-link">
                        Edit
                    </a>

                </div>

                <div class="profile-summary">

                    <p>
                        <strong>Name:</strong>
                        <?= htmlspecialchars($student["name"]) ?>
                    </p>

                    <p>
                        <strong>Email:</strong>
                        <?= htmlspecialchars($student["email"]) ?>
                    </p>

                    <p>
                        <strong>College:</strong>
                        <?= htmlspecialchars($student["college"] ?? "Not added") ?>
                    </p>

                    <p>
                        <strong>Course:</strong>
                        <?= htmlspecialchars($student["course"] ?? "Not added") ?>
                    </p>

                    <p>
                        <strong>Skills:</strong>
                        <?= htmlspecialchars($student["skills"] ?? "Not added") ?>
                    </p>

                </div>

            </div>


            <div class="dashboard-card">

                <div class="card-heading">

                    <div>
                        <p class="eyebrow">QUICK ACTIONS</p>
                        <h2>Get Started</h2>
                    </div>

                </div>

                <div class="quick-actions">

                    <a href="internships.php" class="action-card">
                        <strong>Search Internships</strong>
                        <span>Explore available opportunities</span>
                    </a>

                    <a href="applications.php" class="action-card">
                        <strong>Track Applications</strong>
                        <span>View your application status</span>
                    </a>

                    <a href="profile.php" class="action-card">
                        <strong>Update Profile</strong>
                        <span>Keep your information current</span>
                    </a>

                </div>

            </div>

        </section>

    </main>


    <footer class="footer">
        <p>College Internship Application Portal</p>
    </footer>

</div>

<script src="../js/validation.js"></script>

</body>

</html>