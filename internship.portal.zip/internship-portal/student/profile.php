<?php

session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION["user_id"];

$error = "";
$success = "";

try {

    $stmt = $conn->prepare("
        SELECT
            u.name,
            u.email,
            s.id AS student_id,
            s.phone,
            s.college,
            s.course,
            s.skills,
            s.resume
        FROM users u
        LEFT JOIN students s ON s.user_id = u.id
        WHERE u.id = ?
        LIMIT 1
    ");

    $stmt->execute([$userId]);

    $student = $stmt->fetch();

    if (!$student) {
        header("Location: ../logout.php");
        exit;
    }

} catch (PDOException $e) {
    die("Unable to load profile.");
}


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $phone = trim($_POST["phone"] ?? "");
    $college = trim($_POST["college"] ?? "");
    $course = trim($_POST["course"] ?? "");
    $skills = trim($_POST["skills"] ?? "");

    $resumePath = $student["resume"] ?? null;

    if (isset($_FILES["resume"]) &&
        $_FILES["resume"]["error"] !== UPLOAD_ERR_NO_FILE) {

        if ($_FILES["resume"]["error"] !== UPLOAD_ERR_OK) {

            $error = "Resume upload failed.";

        } else {

            $allowedExtensions = ["pdf", "doc", "docx"];

            $originalName = $_FILES["resume"]["name"];
            $extension = strtolower(
                pathinfo($originalName, PATHINFO_EXTENSION)
            );

            $fileSize = (int) $_FILES["resume"]["size"];

            if (!in_array($extension, $allowedExtensions, true)) {

                $error = "Only PDF, DOC and DOCX files are allowed.";

            } elseif ($fileSize > 5 * 1024 * 1024) {

                $error = "Resume must be smaller than 5 MB.";

            } else {

                $uploadDirectory = __DIR__ . "/../uploads/resumes/";

                if (!is_dir($uploadDirectory)) {
                    mkdir($uploadDirectory, 0755, true);
                }

                $newFileName =
                    "resume_" .
                    $userId .
                    "_" .
                    time() .
                    "." .
                    $extension;

                $destination = $uploadDirectory . $newFileName;

                if (move_uploaded_file(
                    $_FILES["resume"]["tmp_name"],
                    $destination
                )) {

                    $resumePath = "uploads/resumes/" . $newFileName;

                } else {

                    $error = "Unable to save the resume.";
                }
            }
        }
    }


    if ($error === "") {

        try {

            $conn->beginTransaction();

            $updateUser = $conn->prepare("
                UPDATE users
                SET name = ?
                WHERE id = ?
            ");

            $updateUser->execute([
                trim($_POST["name"] ?? $student["name"]),
                $userId
            ]);


            $updateStudent = $conn->prepare("
                UPDATE students
                SET
                    phone = ?,
                    college = ?,
                    course = ?,
                    skills = ?,
                    resume = ?
                WHERE user_id = ?
            ");

            $updateStudent->execute([
                $phone,
                $college,
                $course,
                $skills,
                $resumePath,
                $userId
            ]);

            $conn->commit();

            $_SESSION["user_name"] =
                trim($_POST["name"] ?? $student["name"]);

            $success = "Profile updated successfully.";

            $stmt->execute([$userId]);
            $student = $stmt->fetch();

        } catch (PDOException $e) {

            if ($conn->inTransaction()) {
                $conn->rollBack();
            }

            $error = "Unable to update profile.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Profile | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="page-wrapper">

<header class="navbar">

    <a href="../index.php" class="logo">
        INTERNSHIP<span>PORTAL</span>
    </a>

    <nav>

        <a href="../index.php">Home</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="profile.php" class="active">Profile</a>
        <a href="internships.php">Internships</a>
        <a href="applications.php">Applications</a>
        <a href="../logout.php">Logout</a>

    </nav>

</header>


<main class="form-page">

    <section class="form-card">

        <div class="section-heading left">

            <p class="eyebrow">STUDENT PROFILE</p>

            <h1>Build Your Profile</h1>

            <p>
                Keep your academic and professional information updated.
            </p>

        </div>


        <?php if ($error): ?>

            <div class="alert alert-error">
                <?= htmlspecialchars($error) ?>
            </div>

        <?php endif; ?>


        <?php if ($success): ?>

            <div class="alert alert-success">
                <?= htmlspecialchars($success) ?>
            </div>

        <?php endif; ?>


        <form method="POST"
              enctype="multipart/form-data">

            <div class="form-row">

                <div class="form-group">

                    <label>Full Name</label>

                    <input
                        type="text"
                        name="name"
                        value="<?= htmlspecialchars($student["name"] ?? "") ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Email</label>

                    <input
                        type="email"
                        value="<?= htmlspecialchars($student["email"] ?? "") ?>"
                        disabled
                    >

                </div>

            </div>


            <div class="form-row">

                <div class="form-group">

                    <label>Phone</label>

                    <input
                        type="text"
                        name="phone"
                        value="<?= htmlspecialchars($student["phone"] ?? "") ?>"
                        placeholder="Enter phone number"
                    >

                </div>


                <div class="form-group">

                    <label>College</label>

                    <input
                        type="text"
                        name="college"
                        value="<?= htmlspecialchars($student["college"] ?? "") ?>"
                        placeholder="Enter college name"
                    >

                </div>

            </div>


            <div class="form-group">

                <label>Course</label>

                <input
                    type="text"
                    name="course"
                    value="<?= htmlspecialchars($student["course"] ?? "") ?>"
                    placeholder="Example: B.E Computer Science"
                >

            </div>


            <div class="form-group">

                <label>Skills</label>

                <textarea
                    name="skills"
                    rows="5"
                    placeholder="PHP, MySQL, JavaScript, HTML, CSS..."
                ><?= htmlspecialchars($student["skills"] ?? "") ?></textarea>

            </div>


            <div class="form-group">

                <label>Resume</label>

                <input
                    type="file"
                    name="resume"
                    accept=".pdf,.doc,.docx"
                >

                <small>
                    Accepted: PDF, DOC, DOCX. Maximum size: 5 MB.
                </small>

                <?php if (!empty($student["resume"])): ?>

                    <p class="file-info">
                        Current resume uploaded.
                    </p>

                <?php endif; ?>

            </div>


            <button
                type="submit"
                class="btn btn-primary"
            >
                Save Profile
            </button>

        </form>

    </section>

</main>


<footer class="footer">
    <p>College Internship Application Portal</p>
</footer>

</div>

<script src="../js/validation.js"></script>

</body>

</html>