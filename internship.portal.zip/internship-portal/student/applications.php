<?php

session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION["user_id"];

try {

    $studentStmt = $conn->prepare("
        SELECT id
        FROM students
        WHERE user_id = ?
        LIMIT 1
    ");

    $studentStmt->execute([$userId]);

    $student = $studentStmt->fetch();

    $applications = [];

    if ($student) {

        $stmt = $conn->prepare("
            SELECT
                a.id,
                a.status,
                a.applied_at,
                a.updated_at,
                i.title,
                i.location,
                i.stipend,
                i.duration,
                c.company_name
            FROM applications a
            INNER JOIN internships i
                ON i.id = a.internship_id
            INNER JOIN companies c
                ON c.id = i.company_id
            WHERE a.student_id = ?
            ORDER BY a.applied_at DESC
        ");

        $stmt->execute([
            (int) $student["id"]
        ]);

        $applications = $stmt->fetchAll();
    }

} catch (PDOException $e) {

    $applications = [];
    $error = "Unable to load applications.";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Applications | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="page-wrapper">

<header class="navbar">

    <a href="../index.php" class="logo">
        INTERNSHIP<span>PORTAL</span>
    </a>

    <nav>

        <a href="../index.php">Home</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="profile.php">Profile</a>
        <a href="internships.php">Internships</a>
        <a href="applications.php" class="active">Applications</a>
        <a href="../logout.php">Logout</a>

    </nav>

</header>


<main class="content-container">

    <section class="page-header">

        <p class="eyebrow">APPLICATION TRACKING</p>

        <h1>My Applications</h1>

        <p>
            Track every internship application from submission to final decision.
        </p>

    </section>


    <?php if (isset($error)): ?>

        <div class="alert alert-error">
            <?= htmlspecialchars($error) ?>
        </div>

    <?php endif; ?>


    <?php if (count($applications) === 0): ?>

        <div class="empty-state">

            <h2>No applications yet</h2>

            <p>
                Explore internships and submit your first application.
            </p>

            <a href="internships.php" class="btn btn-primary">
                Find Internships
            </a>

        </div>

    <?php else: ?>

        <div class="table-container">

            <table>

                <thead>

                    <tr>
                        <th>Internship</th>
                        <th>Company</th>
                        <th>Location</th>
                        <th>Applied</th>
                        <th>Status</th>
                    </tr>

                </thead>

                <tbody>

                <?php foreach ($applications as $application): ?>

                    <tr>

                        <td>
                            <strong>
                                <?= htmlspecialchars($application["title"]) ?>
                            </strong>
                        </td>

                        <td>
                            <?= htmlspecialchars($application["company_name"]) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($application["location"]) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($application["applied_at"]) ?>
                        </td>

                        <td>

                            <span class="status status-<?= strtolower(str_replace(" ", "-", $application["status"])) ?>">
                                <?= htmlspecialchars($application["status"]) ?>
                            </span>

                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    <?php endif; ?>

</main>


<footer class="footer">
    <p>College Internship Application Portal</p>
</footer>

</div>

</body>

</html>