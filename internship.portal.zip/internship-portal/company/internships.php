<?php

session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "company") {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION["user_id"];

try {

    $stmt = $conn->prepare("
        SELECT
            c.id
        FROM companies c
        WHERE c.user_id = ?
        LIMIT 1
    ");

    $stmt->execute([$userId]);

    $company = $stmt->fetch();

    if (!$company) {
        die("Company not found.");
    }


    $internshipStmt = $conn->prepare("
        SELECT
            i.id,
            i.title,
            i.description,
            i.skills_required,
            i.location,
            i.stipend,
            i.duration,
            i.deadline,
            i.created_at,
            COUNT(a.id) AS applicant_count
        FROM internships i
        LEFT JOIN applications a
            ON a.internship_id = i.id
        WHERE i.company_id = ?
        GROUP BY
            i.id,
            i.title,
            i.description,
            i.skills_required,
            i.location,
            i.stipend,
            i.duration,
            i.deadline,
            i.created_at
        ORDER BY i.created_at DESC
    ");

    $internshipStmt->execute([
        (int) $company["id"]
    ]);

    $internships = $internshipStmt->fetchAll();

} catch (PDOException $e) {

    $internships = [];
    $error = "Unable to load internships.";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Internships | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="page-wrapper">

<header class="navbar">

    <a href="../index.php" class="logo">
        INTERNSHIP<span>PORTAL</span>
    </a>

    <nav>

        <a href="../index.php">Home</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="internships.php" class="active">Internships</a>
        <a href="applicants.php">Applicants</a>
        <a href="add_internship.php">Add Internship</a>
        <a href="../logout.php">Logout</a>

    </nav>

</header>


<main class="content-container">

    <section class="page-header">

        <div>

            <p class="eyebrow">COMPANY MANAGEMENT</p>

            <h1>My Internships</h1>

            <p>
                Manage your posted internship opportunities.
            </p>

        </div>

        <a href="add_internship.php" class="btn btn-primary">
            Add Internship
        </a>

    </section>


    <?php if (isset($error)): ?>

        <div class="alert alert-error">
            <?= htmlspecialchars($error) ?>
        </div>

    <?php endif; ?>


    <section class="internship-grid">

        <?php if (count($internships) === 0): ?>

            <div class="empty-state">

                <h2>No internships posted</h2>

                <p>
                    Create your first internship opportunity.
                </p>

                <a href="add_internship.php" class="btn btn-primary">
                    Add Internship
                </a>

            </div>

        <?php endif; ?>


        <?php foreach ($internships as $internship): ?>

            <article class="internship-card">

                <div class="card-top">

                    <span class="badge">
                        <?= (int) $internship["applicant_count"] ?>
                        Applicants
                    </span>

                    <span class="location">
                        <?= htmlspecialchars($internship["location"]) ?>
                    </span>

                </div>


                <h2>
                    <?= htmlspecialchars($internship["title"]) ?>
                </h2>


                <p>
                    <?= nl2br(
                        htmlspecialchars(
                            $internship["description"]
                        )
                    ) ?>
                </p>


                <div class="detail-list">

                    <span>
                        <strong>Skills:</strong>
                        <?= htmlspecialchars($internship["skills_required"]) ?>
                    </span>

                    <span>
                        <strong>Stipend:</strong>
                        <?= htmlspecialchars($internship["stipend"]) ?>
                    </span>

                    <span>
                        <strong>Duration:</strong>
                        <?= htmlspecialchars($internship["duration"]) ?>
                    </span>

                    <span>
                        <strong>Deadline:</strong>
                        <?= htmlspecialchars($internship["deadline"]) ?>
                    </span>

                </div>


                <a
                    href="applicants.php?internship_id=<?= (int) $internship["id"] ?>"
                    class="btn btn-secondary btn-full"
                >
                    View Applicants
                </a>

            </article>

        <?php endforeach; ?>

    </section>

</main>


<footer class="footer">
    <p>College Internship Application Portal</p>
</footer>

</div>

</body>

</html>