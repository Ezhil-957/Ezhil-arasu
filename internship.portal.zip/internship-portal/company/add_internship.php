<?php

session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "company") {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION["user_id"];

$error = "";
$success = "";

try {

    $stmt = $conn->prepare("
        SELECT id, company_name
        FROM companies
        WHERE user_id = ?
        LIMIT 1
    ");

    $stmt->execute([$userId]);

    $company = $stmt->fetch();

    if (!$company) {
        die("Company account not found.");
    }

} catch (PDOException $e) {
    die("Unable to load company.");
}


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $title = trim($_POST["title"] ?? "");
    $description = trim($_POST["description"] ?? "");
    $skills = trim($_POST["skills_required"] ?? "");
    $location = trim($_POST["location"] ?? "");
    $stipend = trim($_POST["stipend"] ?? "");
    $duration = trim($_POST["duration"] ?? "");
    $deadline = trim($_POST["deadline"] ?? "");

    if (
        $title === "" ||
        $description === "" ||
        $skills === "" ||
        $location === "" ||
        $stipend === "" ||
        $duration === "" ||
        $deadline === ""
    ) {

        $error = "Please fill in all fields.";

    } elseif (strtotime($deadline) === false) {

        $error = "Please enter a valid deadline.";

    } elseif (strtotime($deadline) < strtotime(date("Y-m-d"))) {

        $error = "Deadline cannot be in the past.";

    } else {

        try {

            $insert = $conn->prepare("
                INSERT INTO internships
                (
                    company_id,
                    title,
                    description,
                    skills_required,
                    location,
                    stipend,
                    duration,
                    deadline
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $insert->execute([
                (int) $company["id"],
                $title,
                $description,
                $skills,
                $location,
                $stipend,
                $duration,
                $deadline
            ]);

            $success = "Internship posted successfully.";

            $_POST = [];

        } catch (PDOException $e) {

            $error = "Unable to create internship.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Add Internship | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="page-wrapper">

<header class="navbar">

    <a href="../index.php" class="logo">
        INTERNSHIP<span>PORTAL</span>
    </a>

    <nav>

        <a href="../index.php">Home</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="internships.php">Internships</a>
        <a href="applicants.php">Applicants</a>
        <a href="add_internship.php" class="active">Add Internship</a>
        <a href="../logout.php">Logout</a>

    </nav>

</header>


<main class="form-page">

    <section class="form-card">

        <p class="eyebrow">OPPORTUNITY CREATION</p>

        <h1>Post an Internship</h1>

        <p>
            Create a clear internship listing for students.
        </p>


        <?php if ($error): ?>

            <div class="alert alert-error">
                <?= htmlspecialchars($error) ?>
            </div>

        <?php endif; ?>


        <?php if ($success): ?>

            <div class="alert alert-success">

                <?= htmlspecialchars($success) ?>

                <br><br>

                <a href="internships.php" class="btn btn-primary">
                    View Internships
                </a>

            </div>

        <?php endif; ?>


        <form method="POST">

            <div class="form-group">

                <label>Internship Title</label>

                <input
                    type="text"
                    name="title"
                    placeholder="Example: PHP Web Development Intern"
                    value="<?= htmlspecialchars($_POST["title"] ?? "") ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label>Description</label>

                <textarea
                    name="description"
                    rows="6"
                    placeholder="Describe the internship..."
                    required
                ><?= htmlspecialchars($_POST["description"] ?? "") ?></textarea>

            </div>


            <div class="form-group">

                <label>Skills Required</label>

                <input
                    type="text"
                    name="skills_required"
                    placeholder="PHP, MySQL, HTML, CSS..."
                    value="<?= htmlspecialchars($_POST["skills_required"] ?? "") ?>"
                    required
                >

            </div>


            <div class="form-row">

                <div class="form-group">

                    <label>Location</label>

                    <input
                        type="text"
                        name="location"
                        placeholder="Chennai / Remote"
                        value="<?= htmlspecialchars($_POST["location"] ?? "") ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Stipend</label>

                    <input
                        type="text"
                        name="stipend"
                        placeholder="₹10,000/month"
                        value="<?= htmlspecialchars($_POST["stipend"] ?? "") ?>"
                        required
                    >

                </div>

            </div>


            <div class="form-row">

                <div class="form-group">

                    <label>Duration</label>

                    <input
                        type="text"
                        name="duration"
                        placeholder="3 Months"
                        value="<?= htmlspecialchars($_POST["duration"] ?? "") ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Application Deadline</label>

                    <input
                        type="date"
                        name="deadline"
                        value="<?= htmlspecialchars($_POST["deadline"] ?? "") ?>"
                        required
                    >

                </div>

            </div>


            <button
                type="submit"
                class="btn btn-primary"
            >
                Publish Internship
            </button>

        </form>

    </section>

</main>


<footer class="footer">
    <p>College Internship Application Portal</p>
</footer>

</div>

<script src="../js/validation.js"></script>

</body>

</html>