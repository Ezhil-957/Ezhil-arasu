<?php

session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "company") {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION["user_id"];

$error = "";
$success = "";

try {

    $companyStmt = $conn->prepare("
        SELECT id, company_name
        FROM companies
        WHERE user_id = ?
        LIMIT 1
    ");

    $companyStmt->execute([$userId]);

    $company = $companyStmt->fetch();

    if (!$company) {
        die("Company not found.");
    }

    $companyId = (int) $company["id"];


    /*
     * Update application status.
     */
    if ($_SERVER["REQUEST_METHOD"] === "POST") {

        $applicationId = (int) ($_POST["application_id"] ?? 0);
        $newStatus = trim($_POST["status"] ?? "");

        $allowedStatuses = [
            "Applied",
            "Under Review",
            "Shortlisted",
            "Interview",
            "Selected",
            "Rejected"
        ];

        if (
            $applicationId <= 0 ||
            !in_array($newStatus, $allowedStatuses, true)
        ) {

            $error = "Invalid application status.";

        } else {

            /*
             * Make sure the application belongs to this company.
             */
            $update = $conn->prepare("
                UPDATE applications a
                INNER JOIN internships i
                    ON i.id = a.internship_id
                SET
                    a.status = ?,
                    a.updated_at = CURRENT_TIMESTAMP
                WHERE a.id = ?
                  AND i.company_id = ?
            ");

            $update->execute([
                $newStatus,
                $applicationId,
                $companyId
            ]);

            if ($update->rowCount() > 0) {
                $success = "Application status updated.";
            } else {
                $error = "Unable to update application.";
            }
        }
    }


    $internshipId = (int) ($_GET["internship_id"] ?? 0);

    if ($internshipId > 0) {

        $verify = $conn->prepare("
            SELECT id, title
            FROM internships
            WHERE id = ?
              AND company_id = ?
            LIMIT 1
        ");

        $verify->execute([
            $internshipId,
            $companyId
        ]);

        $selectedInternship = $verify->fetch();

        if (!$selectedInternship) {
            $error = "Internship not found.";
            $internshipId = 0;
        }
    }


    if ($internshipId > 0) {

        $stmt = $conn->prepare("
            SELECT
                a.id,
                a.status,
                a.applied_at,
                a.updated_at,
                a.resume,
                u.name,
                u.email,
                s.phone,
                s.college,
                s.course,
                s.skills,
                i.title
            FROM applications a
            INNER JOIN students s
                ON s.id = a.student_id
            INNER JOIN users u
                ON u.id = s.user_id
            INNER JOIN internships i
                ON i.id = a.internship_id
            WHERE a.internship_id = ?
              AND i.company_id = ?
            ORDER BY a.applied_at DESC
        ");

        $stmt->execute([
            $internshipId,
            $companyId
        ]);

    } else {

        $stmt = $conn->prepare("
            SELECT
                a.id,
                a.status,
                a.applied_at,
                a.updated_at,
                a.resume,
                u.name,
                u.email,
                s.phone,
                s.college,
                s.course,
                s.skills,
                i.title
            FROM applications a
            INNER JOIN students s
                ON s.id = a.student_id
            INNER JOIN users u
                ON u.id = s.user_id
            INNER JOIN internships i
                ON i.id = a.internship_id
            WHERE i.company_id = ?
            ORDER BY a.applied_at DESC
        ");

        $stmt->execute([$companyId]);
    }

    $applications = $stmt->fetchAll();

} catch (PDOException $e) {

    $applications = [];

    if ($error === "") {
        $error = "Unable to load applicants.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Applicants | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="page-wrapper">

<header class="navbar">

    <a href="../index.php" class="logo">
        INTERNSHIP<span>PORTAL</span>
    </a>

    <nav>

        <a href="../index.php">Home</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="internships.php">Internships</a>
        <a href="applicants.php" class="active">Applicants</a>
        <a href="add_internship.php">Add Internship</a>
        <a href="../logout.php">Logout</a>

    </nav>

</header>


<main class="content-container">

    <section class="page-header">

        <p class="eyebrow">CANDIDATE MANAGEMENT</p>

        <h1>Applicants</h1>

        <p>
            Review candidates and update their application status.
        </p>

    </section>


    <?php if ($error): ?>

        <div class="alert alert-error">
            <?= htmlspecialchars($error) ?>
        </div>

    <?php endif; ?>


    <?php if ($success): ?>

        <div class="alert alert-success">
            <?= htmlspecialchars($success) ?>
        </div>

    <?php endif; ?>


    <?php if (count($applications) === 0): ?>

        <div class="empty-state">

            <h2>No applicants yet</h2>

            <p>
                Applications will appear here when students apply.
            </p>

        </div>

    <?php else: ?>

        <section class="applicant-list">

            <?php foreach ($applications as $application): ?>

                <article class="applicant-card">

                    <div class="applicant-info">

                        <p class="eyebrow">
                            <?= htmlspecialchars($application["title"]) ?>
                        </p>

                        <h2>
                            <?= htmlspecialchars($application["name"]) ?>
                        </h2>

                        <p>
                            <strong>Email:</strong>
                            <?= htmlspecialchars($application["email"]) ?>
                        </p>

                        <p>
                            <strong>Phone:</strong>
                            <?= htmlspecialchars($application["phone"] ?? "Not provided") ?>
                        </p>

                        <p>
                            <strong>College:</strong>
                            <?= htmlspecialchars($application["college"] ?? "Not provided") ?>
                        </p>

                        <p>
                            <strong>Course:</strong>
                            <?= htmlspecialchars($application["course"] ?? "Not provided") ?>
                        </p>

                        <p>
                            <strong>Skills:</strong>
                            <?= htmlspecialchars($application["skills"] ?? "Not provided") ?>
                        </p>

                        <p>
                            <strong>Applied:</strong>
                            <?= htmlspecialchars($application["applied_at"]) ?>
                        </p>

                        <?php if (!empty($application["resume"])): ?>

                            <p>
                                <strong>Resume:</strong>
                                <?= htmlspecialchars(basename($application["resume"])) ?>
                            </p>

                        <?php endif; ?>

                    </div>


                    <div class="applicant-actions">

                        <span class="status status-<?= strtolower(str_replace(" ", "-", $application["status"])) ?>">
                            <?= htmlspecialchars($application["status"]) ?>
                        </span>


                        <form method="POST">

                            <input
                                type="hidden"
                                name="application_id"
                                value="<?= (int) $application["id"] ?>"
                            >

                            <label>
                                Update Status
                            </label>

                            <select name="status">

                                <?php
                                $statuses = [
                                    "Applied",
                                    "Under Review",
                                    "Shortlisted",
                                    "Interview",
                                    "Selected",
                                    "Rejected"
                                ];
                                ?>

                                <?php foreach ($statuses as $status): ?>

                                    <option
                                        value="<?= htmlspecialchars($status) ?>"
                                        <?= $application["status"] === $status ? "selected" : "" ?>
                                    >
                                        <?= htmlspecialchars($status) ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                            <button
                                type="submit"
                                class="btn btn-primary"
                            >
                                Update Status
                            </button>

                        </form>

                    </div>

                </article>

            <?php endforeach; ?>

        </section>

    <?php endif; ?>

</main>


<footer class="footer">
    <p>College Internship Application Portal</p>
</footer>

</div>

</body>

</html>