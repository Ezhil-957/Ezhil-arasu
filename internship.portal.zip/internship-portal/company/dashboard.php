<?php

session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "company") {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION["user_id"];

try {

    $companyStmt = $conn->prepare("
        SELECT
            c.id,
            c.company_name,
            c.company_description,
            c.website,
            c.location,
            u.name,
            u.email
        FROM companies c
        INNER JOIN users u
            ON u.id = c.user_id
        WHERE c.user_id = ?
        LIMIT 1
    ");

    $companyStmt->execute([$userId]);

    $company = $companyStmt->fetch();

    if (!$company) {
        die("Company profile not found.");
    }

    $companyId = (int) $company["id"];


    $statsStmt = $conn->prepare("
        SELECT
            COUNT(DISTINCT i.id) AS internships,
            COUNT(a.id) AS applications,
            SUM(a.status = 'Under Review') AS under_review,
            SUM(a.status = 'Shortlisted') AS shortlisted,
            SUM(a.status = 'Interview') AS interview,
            SUM(a.status = 'Selected') AS selected
        FROM internships i
        LEFT JOIN applications a
            ON a.internship_id = i.id
        WHERE i.company_id = ?
    ");

    $statsStmt->execute([$companyId]);

    $stats = $statsStmt->fetch();

} catch (PDOException $e) {

    die("Unable to load company dashboard.");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Company Dashboard | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="page-wrapper">

<header class="navbar">

    <a href="../index.php" class="logo">
        INTERNSHIP<span>PORTAL</span>
    </a>

    <nav>

        <a href="../index.php">Home</a>
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="internships.php">Internships</a>
        <a href="applicants.php">Applicants</a>
        <a href="add_internship.php">Add Internship</a>
        <a href="../logout.php">Logout</a>

    </nav>

</header>


<main class="dashboard-container">

    <section class="dashboard-header">

        <div>

            <p class="eyebrow">COMPANY DASHBOARD</p>

            <h1>
                Welcome, <?= htmlspecialchars($company["company_name"]) ?>
            </h1>

            <p>
                Manage internships and review student applications.
            </p>

        </div>

        <a href="add_internship.php" class="btn btn-primary">
            Add Internship
        </a>

    </section>


    <section class="stats-grid">

        <div class="stat-card">

            <span>Internships</span>

            <strong>
                <?= (int) ($stats["internships"] ?? 0) ?>
            </strong>

        </div>


        <div class="stat-card">

            <span>Applications</span>

            <strong>
                <?= (int) ($stats["applications"] ?? 0) ?>
            </strong>

        </div>


        <div class="stat-card">

            <span>Under Review</span>

            <strong>
                <?= (int) ($stats["under_review"] ?? 0) ?>
            </strong>

        </div>


        <div class="stat-card">

            <span>Shortlisted</span>

            <strong>
                <?= (int) ($stats["shortlisted"] ?? 0) ?>
            </strong>

        </div>


        <div class="stat-card">

            <span>Interview</span>

            <strong>
                <?= (int) ($stats["interview"] ?? 0) ?>
            </strong>

        </div>


        <div class="stat-card">

            <span>Selected</span>

            <strong>
                <?= (int) ($stats["selected"] ?? 0) ?>
            </strong>

        </div>

    </section>


    <section class="dashboard-grid">

        <div class="dashboard-card">

            <p class="eyebrow">COMPANY</p>

            <h2>
                <?= htmlspecialchars($company["company_name"]) ?>
            </h2>

            <p>
                <?= nl2br(
                    htmlspecialchars(
                        $company["company_description"] ?? "No description added."
                    )
                ) ?>
            </p>

            <p>
                <strong>Location:</strong>
                <?= htmlspecialchars($company["location"] ?? "Not specified") ?>
            </p>

            <p>
                <strong>Website:</strong>
                <?= htmlspecialchars($company["website"] ?? "Not specified") ?>
            </p>

        </div>


        <div class="dashboard-card">

            <p class="eyebrow">QUICK ACTIONS</p>

            <h2>Management</h2>

            <div class="quick-actions">

                <a href="add_internship.php" class="action-card">
                    <strong>Post Internship</strong>
                    <span>Create a new opportunity</span>
                </a>

                <a href="internships.php" class="action-card">
                    <strong>Manage Internships</strong>
                    <span>View your posted internships</span>
                </a>

                <a href="applicants.php" class="action-card">
                    <strong>Review Applicants</strong>
                    <span>Manage candidate applications</span>
                </a>

            </div>

        </div>

    </section>

</main>


<footer class="footer">
    <p>College Internship Application Portal</p>
</footer>

</div>

</body>

</html>