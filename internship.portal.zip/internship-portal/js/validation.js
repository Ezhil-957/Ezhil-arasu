document.addEventListener("DOMContentLoaded", function () {

    /*
    |--------------------------------------------------------------------------
    | Button click effect
    |--------------------------------------------------------------------------
    */

    document.querySelectorAll(".btn").forEach(function (button) {

        button.addEventListener("click", function () {

            button.classList.add("clicked");

            setTimeout(function () {
                button.classList.remove("clicked");
            }, 500);

        });

    });


    /*
    |--------------------------------------------------------------------------
    | Registration validation
    |--------------------------------------------------------------------------
    */

    const registerForm = document.getElementById("registerForm");

    if (registerForm) {

        registerForm.addEventListener("submit", function (event) {

            const password =
                document.getElementById("password");

            const confirmPassword =
                document.getElementById("confirm_password");

            if (password && password.value.length < 6) {

                event.preventDefault();

                alert("Password must contain at least 6 characters.");

                password.focus();

                return;
            }

            if (
                password &&
                confirmPassword &&
                password.value !== confirmPassword.value
            ) {

                event.preventDefault();

                alert("Passwords do not match.");

                confirmPassword.focus();
            }

        });

    }


    /*
    |--------------------------------------------------------------------------
    | Login validation
    |--------------------------------------------------------------------------
    */

    const loginForm = document.getElementById("loginForm");

    if (loginForm) {

        loginForm.addEventListener("submit", function (event) {

            const email =
                document.getElementById("email");

            const password =
                document.getElementById("password");

            if (!email.value.trim()) {

                event.preventDefault();

                alert("Please enter your email.");

                email.focus();

                return;
            }

            if (!password.value.trim()) {

                event.preventDefault();

                alert("Please enter your password.");

                password.focus();

            }

        });

    }


    /*
    |--------------------------------------------------------------------------
    | Prevent double submission
    |--------------------------------------------------------------------------
    */

    document.querySelectorAll("form").forEach(function (form) {

        form.addEventListener("submit", function () {

            const submitButton =
                form.querySelector(
                    'button[type="submit"]'
                );

            if (submitButton) {

                setTimeout(function () {

                    submitButton.disabled = true;

                    submitButton.dataset.originalText =
                        submitButton.textContent;

                    submitButton.textContent =
                        "Processing...";

                }, 0);
            }

        });

    });

});